package assistedproject2;

	//parameterized constructor
	class Std{
		int id;
		String name;

		Std(int i,String n)
		{
		id=i;
		name=n;
		}

		void display() {
		System.out.println(id+" "+name);
		}
	}

	public class parameterizedconstructor {
	public static void main(String[] args) {

		Std std1=new Std(3,"prashanth");
		Std std2=new Std(9,"reddy");
		std1.display();
		std2.display();
			}
	
}



