package assistedproject3;


	import java.util.Hashtable;
	import java.util.Map;

	public class table {

		public static void main(String[] args) {
			//HashTable
		       
		      Hashtable<Integer,String> ht=new Hashtable<Integer,String>();  
		      
		      ht.put(4,"nani");  
		      ht.put(5,"prashanth");  
		      ht.put(6,"ravi");  
		      ht.put(7,"John");  

		      System.out.println("\nThe elements of HashTable are ");  
		      for(Map.Entry n:ht.entrySet()){    
		       System.out.println(n.getKey()+" "+n.getValue());    
		      }


		}

	}



