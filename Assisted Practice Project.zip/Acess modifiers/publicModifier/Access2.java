package publicModifier;

public class Access2 {

	
		
			public static void main(String[] args) {
				
				
					Access1 obj= new Access1();
					
					System.out.println("Name:" +obj.fname+" "+obj.lname);
					System.out.println("Mail:" +obj.mail);
					System.out.println("Age:" +obj.age);
					
				}

			

	}


