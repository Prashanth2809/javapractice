package publicModifier;

public class Access1 {
		
			// public class
			public String fname="xyz";
	
			public String lname="abc";
			public String mail="xyz@mail.com";
			public int age=23;
		    public static void main(String[] args) {
		    	
		    }
			
		}

