package pack1;

public class protectedclass {
	protected String fname="xyz";
	protected String lname="abc";
	protected int age=20;
	public static void main (String[] args) {
		
	}
	
}
//creating another class that extends class access1
class protectedclass1 extends  protectedclass{
	//we can use all i.e public, private,protected,default
	private int yob=2005;
	public static void main (String[] args) {
		protectedclass1 obj= new protectedclass1();
		System.out.println("Name:"+obj.fname+""+obj.lname);
		System.out.println("Age:"+obj.age);
		System.out.println("YOB:"+obj.yob);
		
		
	}
	
}


