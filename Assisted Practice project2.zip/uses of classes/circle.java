package abstraction;

public class circle {
private double radius;
	
	public  circle(double radius,String color) {
		super();
		this.radius=radius;
	}
	
	double area() {
		//area of circle is pi * r^2
		return Math.PI * Math.pow(radius,2);
	}


	public static void main(String[] args) {}
		// TODO Auto-generated method stub
		@Override
		public String toString() {
			return "Circle  Color: ="+getColor()+"  and area is: "+area();


	}

		private String getColor() {
			// TODO Auto-generated method stub
			return null;
		}

}
