package assistedproject7;
import java.io.File;

import java.io.FileWriter;
import java.io.IOException;



public class Create {
	
	public static void createFileUsingFileClass() throws IOException
	{
		//create file
		File file= new File("C:\\files\\testFile22-07-22.txt");
		
		if(file.createNewFile()) {
			System.out.println("File is Created");
		}
		else {
			System.out.println("File  is already Exist");
		}
		
		//write data to that file
		FileWriter  writer= new  FileWriter(file,false);//overWrites file
		//FileWriter  writer= new  FileWriter(file,true);//appends File
		writer.write("Welcometo Simplilearn...!");
		writer.close();
		
		
	}


	public static void main(String[] args) {
		try {
			createFileUsingFileClass();
		}
		catch (IOException e) {
			
			//e.printStackTrace();
			System.out.println("File not available");
		}
	
	
}


	}


