package assistedproject7;
import java.io.FileReader;
import java.io.IOException;


public class Readfile {
	public static void readFileReaderClass() throws IOException
	{ 
		FileReader reader= new FileReader("C:\\files\\testFile22-07-22.txt");
		
		int data;
		
		while((data=reader.read())!=-1){
			
			System.out.print((char)data);
		}
		
}

	public static void main(String[] args) {
		try {
			readFileReaderClass();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("File not available");
		}
		
	}	
}
	


